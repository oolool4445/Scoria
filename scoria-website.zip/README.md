# Scoria Website

Website sederhana bertema batuan Skoria (batuan vulkanik berpori).

## Fitur
- Desain dark volcanic theme
- Informasi dasar tentang skoria
- Siap upload ke GitHub

## Cara Menjalankan
Buka file index.html di browser.
